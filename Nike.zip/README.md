# Website Quản lý tiệm thú cưng
**Website Quản lý tiệm thú cưng**  
> Thực hiện: **Trịnh Hữu Gia Bảo**  
Dự án website quản lý tiệm thú cưng được thực hiện bởi sinh viên HUFLIT, website được thiết kế bởi mô hình Model-View-Controller, quy trình thực hiện dựa trên tiến trình Scrum, project bắt đầu vào ngày 20/09/2024 và kết thúc vào ngày 20/11/2024.   
Dự án bao gồm 5 sprint tương ứng với 10 tuần thực hiện  
Dữ liệu được lưu trữ trên SQL sever, kết nối dự liệu đến project thông qua EntityFramework

