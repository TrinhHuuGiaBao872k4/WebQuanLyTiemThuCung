namespace Nike.Areas.Admin.Services
{
    public interface IOrderService
    {
        List<Order> GetOrders();
    }
}