namespace Nike.Areas.Admin.Services
{
    public interface ILogger
    {
        void Log(string message);
    }
}